/** Automatically generated file. DO NOT MODIFY */
package object.dbnewgo.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}