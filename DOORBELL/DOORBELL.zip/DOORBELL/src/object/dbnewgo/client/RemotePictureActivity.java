package object.dbnewgo.client;

import android.os.Bundle;

/**
 * Զ��TF���� ��ͼƬ
 * */
public class RemotePictureActivity extends BaseActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
}
