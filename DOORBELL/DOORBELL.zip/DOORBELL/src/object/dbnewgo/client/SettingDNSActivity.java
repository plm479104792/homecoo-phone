package object.dbnewgo.client;

import android.os.Bundle;

/**
 * DNS����
 * */
public class SettingDNSActivity extends BaseActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}
