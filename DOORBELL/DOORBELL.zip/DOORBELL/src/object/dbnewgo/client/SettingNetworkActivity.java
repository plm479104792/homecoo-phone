package object.dbnewgo.client;

/**
 * ��������
 * */
public class SettingNetworkActivity extends BaseActivity {
	protected void onCreate(android.os.Bundle savedInstanceState) {

	}
}
