package object.dbnewgo.client;

import android.os.Bundle;
/**
 * ����̨����
 * */
public class SettingPtzActivity extends BaseActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    }
}
