package object.dbnewgo.client.other;

import object.dbnewgo.client.BaseActivity;
import android.os.Bundle;

/**
 * @author zhaogenghuai
 * @creation 2012-12-26����11:27:32
 */
public class OtherMoreFunctionActivity extends BaseActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
}
