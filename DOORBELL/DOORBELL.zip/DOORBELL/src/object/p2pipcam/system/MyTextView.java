package object.p2pipcam.system;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * @author : �Թ���
 * @version ��2012-12-25 ����14:52:21
 */
public class MyTextView extends TextView {

	public MyTextView(Context context) {
		super(context);
	}

	public MyTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	public boolean isFocused() {
		// TODO Auto-generated method stub
		return true;
	}
}
