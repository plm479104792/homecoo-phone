
package object.p2pipcam.utils;


public class CustomBufferData{
	public CustomBufferHead head;
	public byte[] data;
}