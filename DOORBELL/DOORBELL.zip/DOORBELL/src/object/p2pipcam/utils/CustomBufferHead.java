package object.p2pipcam.utils;

public class CustomBufferHead{
	public int startcode;
	public int length;
}